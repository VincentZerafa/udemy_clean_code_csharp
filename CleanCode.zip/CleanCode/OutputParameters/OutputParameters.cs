﻿using CleanCode.Comments;
using System;
using System.Collections.Generic;

namespace CleanCode.OutputParameters
{
    public class OutputParameters
    {
        public class CustomerResults
        {
            public IEnumerable<Customer> Customers { get; set; }
            public int TotalCount { get; set; }

        }

        public void DisplayCustomers()
        {
            var pageIndex = 1;
            var results = GetCustomers(pageIndex);

            Console.WriteLine("Total customers: " + results.TotalCount);
            foreach (var c in results.Customers)
                Console.WriteLine(c);
        }

        public CustomerResults GetCustomers(int pageIndex)
        {
            var totalCount = 100;
            return new CustomerResults() { Customers = new List<Customer>(), TotalCount = totalCount };
        }
    }
}
