﻿
using System;

namespace CleanCode.DuplicatedCode
{
    internal class Time
    {
        public Time(int hours, int minutes)
        {
            Hours = hours;
            Minutes = minutes;
        }

        public int Hours { get; set; }
        public int Minutes { get; set; }
    }

    class DuplicatedCode
    {
        public void AdmitGuest(string name, string admissionDateTime)
        {
            var time = Parse(admissionDateTime);
            
            if (time.Hours < 10)
            {

            }
        }

        public void UpdateAdmission(int admissionId, string name, string admissionDateTime)
        {
            var time = Parse(admissionDateTime);
            
            if (time.Hours < 10)
            {

            }
        }

        public Time Parse(string dateTime)
        {
            if (string.IsNullOrWhiteSpace(dateTime))
                throw new ArgumentNullException("dateTime");
            
            var time = int.Parse(dateTime.Replace(":", ""));

            var hours = time / 100;
            var minutes = time % 100;

            return new Time(hours, minutes);
        }
    }
}
