﻿namespace CleanCode.MagicNumbers
{
    public enum DocumentStatus
    {
        Draft = 1,
        Lodged = 2
    }
}