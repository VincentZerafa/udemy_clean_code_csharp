﻿using System;

namespace CleanCode.Tuples
{
    public class Bill
    {
        public Bill(int totalDue, int totalOverDue)
        {
            TotalDue = totalDue;
            TotalOverDue = totalOverDue;
        }
        
        public int TotalDue { get; }
        public int TotalOverDue { get; }

    }

    public class Tuples
    {
        
        public Bill GetDueBillsCount(int pageIndex)
        {
            return new Bill(0, 0);
        }

        public void DisplayCustomers()
        {
            var dueBillsCount = GetDueBillsCount(1);
            Console.WriteLine(dueBillsCount.TotalDue);
            Console.WriteLine(dueBillsCount.TotalOverDue);
        }
    }
}
