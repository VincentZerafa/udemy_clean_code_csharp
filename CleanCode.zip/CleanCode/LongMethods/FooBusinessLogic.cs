﻿using System;
using System.Data;
using System.IO;

namespace FooFoo
{
    public class FooBusinessLogic
    {
        public FooRepository FooRepository { get; set; }

        public FooBusinessLogic(string connectionString)
        {
            FooRepository = new FooRepository(connectionString);
        }

        public byte[] CreateMemoryFile()
        {
            byte[] byteArray;

            using (MemoryStream memoryStream = new MemoryStream())
            {
                var data = FooRepository.GetData();
                
                using (StreamWriter writer = new StreamWriter(memoryStream))
                {
                    var columns = WriteColumns(data, writer);
            
                    WriteRows(data, writer, columns);
                }

                byteArray = memoryStream.ToArray();
            }

            return byteArray;
        }
        
        private static int WriteColumns(DataTable dt, StreamWriter sw)
        {
            int columns = dt.Columns.Count;

            for (int col = 0; col < columns; col++)
            {
                sw.Write(dt.Columns[col]);
                if (col < columns - 1)
                {
                    sw.Write(",");
                }
            }

            sw.WriteLine();
            return columns;
        }

        private static void WriteRows(DataTable data, StreamWriter writer, int columns)
        {
            foreach (DataRow row in data.Rows)
            {
                WriteRow(row, writer, columns);
            }
        }

        private static void WriteRow(DataRow row, StreamWriter writer, int columns)
        {
            for (int col = 0; col < columns; col++)
            {
                WriteCell(row, writer, col);

                WriteCommaIfNotLastColumn(writer, columns, col);
            }

            writer.WriteLine();
        }
    
        private static void WriteCell(DataRow row, StreamWriter writer, int col)
        {
            if (!Convert.IsDBNull(row[col]))
            {
                string str = String.Format("\"{0:c}\"", row[col].ToString()).Replace("\r\n", " ");
                writer.Write(str);
            }
            else
            {
                writer.Write("");
            }
        }
        
        private static void WriteCommaIfNotLastColumn(StreamWriter writer, int columns, int col)
        {
            if (col < columns - 1)
            {
                writer.Write(",");
            }
        }
    }
}