﻿using System.Data;
using System.Data.SqlClient;

namespace FooFoo
{
    public class FooRepository
    {
        public FooRepository(string connectionString)
        {
            ConnectionString = connectionString;
        }

        public string ConnectionString { get; set; }
        
        public DataTable GetData()
        {
            SqlConnection connection = new SqlConnection(ConnectionString);
            SqlDataAdapter dataAdapter = new SqlDataAdapter("SELECT * FROM [FooFoo] ORDER BY id ASC", connection);
            DataSet dataSet = new DataSet();
            dataAdapter.Fill(dataSet, "FooFoo");
            DataTable data = dataSet.Tables["FooFoo"];
            return data;
        }
    }
}